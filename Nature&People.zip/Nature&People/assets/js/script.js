function toggleAccordion(header) {
    const accordionItem = header.parentElement;
    accordionItem.classList.toggle("active");
}